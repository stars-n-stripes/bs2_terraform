# Notes Relevant to the Project

## DO Guides
+ https://www.digitalocean.com/community/tutorials/how-to-structure-a-terraform-project
+ [Multi-stage course](https://www.digitalocean.com/community/tutorial_series/how-to-manage-infrastructure-with-terraform)


## General Notes
+ non-terraform (HCL) scripts you call should go in an "external" directory
+ You can store variables DO needs in terraform by exporting them in bash like `export DO_{VAR_NAME}="some value"`, then adding them as -var parameters in the terraform command
