import json, time, sys

try:
    prefix = "web"
    final = { "name": f"{prefix}-{int(time.time())}" }
    print(json.dumps(final))
except:
    sys.stderr.write("Failed to build droplet name: " + final["name"] + "\n")
    sys.exit(-1)

